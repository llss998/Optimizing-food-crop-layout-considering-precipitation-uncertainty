function f = tournament_selection(chromosome, pool_size, tour_size)
[pop, variables] = size(chromosome);
rank = variables - 1;
distance = variables;
dominance_strength = variables;

for i = 1 : pool_size
    for j = 1 : tour_size
        candidate(j) = round(pop*rand(1));
        if candidate(j) == 0
            candidate(j) = 1;
        end
        if j > 1
            while ~isempty(find(candidate(1 : j - 1) == candidate(j)))%防止两个参赛个体是同一个
                candidate(j) = round(pop*rand(1));
                if candidate(j) == 0
                    candidate(j) = 1;
                end
            end
        end
    end
    for j = 1 : tour_size
        c_obj_rank(j) = chromosome(candidate(j),rank);
        c_obj_distance(j) = chromosome(candidate(j),distance);
        c_dominance_strength(j)=chromosome(candidate(j),dominance_strength)
    end
    min_candidate = ...
        find(c_obj_rank == min(c_obj_rank));
    if length(min_candidate) ~= 1
        max_candidate = ...
        find(c_obj_distance(min_candidate) == max(c_obj_distance(min_candidate)));
        if length(max_candidate) ~= 1
            max_candidate = max_candidate(1);
            if length(max_candidate) ~= 1
             min_strength_candidate = find(c_obj_dominance(min_candidate(max_candidate)) == min(c_obj_dominance(min_candidate(max_candidate))));
        end
        f(i, :) = chromosome(candidate(min_candidate(max_candidate(min_strength_candidate))), :);
            else
                f(i, :) = chromosome(candidate(min_candidate(max_candidate(1))), :);
            end
        else
                    f(i, :) = chromosome(candidate(min_candidate(1)), :);
    end
end
end