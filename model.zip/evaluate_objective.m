function f = evaluate_objective(x, M, V)
a=0.2;
b=0.4;
CS1ij=[];
CS2ij=[];
CS3ij=[];
CS4ij=[];
I1_1=[];
I2_2=[];
I3_3=[];
I4_1=[];
I4_2=[];
NC1=[];
NC2=[];
NC3=[];
NC4_1=[];
NC4_2=[];
FP1=[];
FP2=[];
FP3=[];
FP41=[];
FP42=[];
%
C1=1162617;
C2=1531737;
C3=1179969;
C4_1=1145667;
C4_2=1135787;
P1=2.01796;
P2=2.39384;
P3=5.21928;
CS1=3;
CS2=3;
CS3=3;
CS4=3;
CS=[CS1,CS2,CS3,CS4];
Sact_1=1197;
Sact_2=233;
Sact_3=564;
Sact_4=9303;
Stotal=16894
S=100;
QE=130480000;
QL=540280000;
QI=214880000;
OW=214880000;
GW=1917950000;
SW=1996290000;
Sdisturb=234730000;



K=x(1:V/2);


XK=x(V/2+1:V).*K; 

f = [];


K3=zeros(1,V/2);
for i=1:V/2
    if K(i)==3
        K3(i)=FP3(i);
    else K3(i)=0
    end
f(1)=sum(K3);


FP=zeros(1,V/2);
E=zeros(1,V/2);
NC=zeros(1,V/2);
I=zeros(1,V/2);
P=[P1,P2,P3];
for i=1:V/2
    if K(i)==1
        FP(i)=FP1(i);
        E(i)=FP(i)*P(1)-C1;
        NC(i)=NC1(i);
        I(i)=I1_1(i);
    elseif K(i)==2
        FP(i)=FP2(i);
        E(i)=FP(i)*P(2)-C2;
        NC(i)=NC2(i);
        I(i)=I2_2(i);
    elseif K(i)==3
        FP(i)=FP3(i);
        E(i)=FP(i)*P(3)-C3;
        NC(i)=NC3(i);
        I(i)=I3_3(i);
    elseif K(i)==4
           FP(i)=FP41(i)+FP42(i);
           NC(i)=NC4_1(i)+I4_2(i);
           I(i)=I4_1(i)+I4_2(i);
           E(i)=FP(i)*P(1)-C4_1+FP(i)*P(2)-C4_2;
        
    end
end
f(2) = sum(E);


f(3)=sum(NC)/sum(FP);

f(4)=sum(FP)/sum(I);

end