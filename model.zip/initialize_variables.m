function f = initialize_variables(N, M, V, min_range, max_range)
min = min_range;
max = max_range;
K = M + V;
for i = 1 : N
    flag=0;
    while flag==0
        for j = 1 : V/2
            f(i,j) = round(min(j) + (max(j) - min(j))*rand(1));                                            %这行代码为每个个体的所有决策变量在约束条件内随机取值
        end
        for j=1+V/2:V
            if f(i,j-V/2)==4
                f(i,j)=round(1+rand) ;
            else
                f(i,j)=f(i,j-V/2);
            end
        end
        flag=test(f(i,:),V);
    end
    f(i,V + 1: K) = evaluate_objective(f(i,:), M, V); 
end