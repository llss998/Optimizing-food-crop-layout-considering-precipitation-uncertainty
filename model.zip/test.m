function flag = test(x,V)
a=0.2;
b=0.4;
CS1ij=[];
CS2ij=[];
CS3ij=[];
CS4ij=[];
I1_1=[];
I2_2=[];
I3_3=[];
I4_1=[];
I4_2=[];
NC1=[];
NC2=[];
NC3=[];
NC4_1=[];
NC4_2=[];
FP1=[];
FP2=[];
FP3=[];
FP41=[];
FP42=[];
%
C1=1162617;
C2=1531737;
C3=1179969;
C4_1=1145667;
C4_2=1135787;
P1=2.01796;
P2=2.39384;
P3=5.21928;
CS1=3;
CS2=3;
CS3=3;
CS4=3;
CS=[CS1,CS2,CS3,CS4];
Sact_1=1197;
Sact_2=233;
Sact_3=564;
Sact_4=9303;
Stotal=16894
S=100;
QE=130480000;
QL=540280000;
QI=214880000;
OW=214880000;
GW=1917950000;
SW=1996290000;
Sdisturb=234730000;

%研究区栅格的种植方式
K=x(1:V/2);

%研究区作物的种类
XK=x(V/2+1:V).*K; 
FP=zeros(1,V/2);
FPP=zeros(1,V/2);
NE=zeros(1,V/2);
ET=zeros(1,V/2);
P=[P1,P2,P3];
%CSS=zeros(1,V/2);
%CSK=zeros(1,V/2);
for i=1:V/2
    if K(i)==1
        FP(i)=FP1(i);
        E(i)=FP(i)*P(1)-C1;
        NC(i)=NC1(i);
        I(i)=I1_1(i);
        CSS(i)=CS1ij(i);
        CSK(i)=CS1;
    elseif K(i)==2
        FP(i)=FP2(i);
        E(i)=FP(i)*P(2)-C2;
        NC(i)=NC2(i);
        I(i)=I2_I2(i);
        CSS(i)=CS2ij(i);
        CSK(i)=CS2;
    elseif K(i)==3
        FP(i)=FP3(i);
        E(i)=FP(i)*P(3)-C3;
        NC(i)=NC3(i);
        I(i)=I3_3(i);
        CSS(i)=CS3ij(i);
        CSK(i)=CS3;
    elseif K(i)==4
           FP(i)=FP41(i)+FP42(i);
           NC(i)=NC4_1(i)+NC4_2(i);
           I(i)=I4_1(i)+I4_2(i);
           E(i)=FP(i)*P(1)-C4_1+FP(i)*P(2)-C4_2;
           CSS(i)=CS4ij(i);
           CSK(i)=CS4;
        
    end
end
N(1)=length(find(K==1));
N(2)=length(find(K==2));
N(3)=length(find(K==3));
N(4)=length(find(K==4));

LN=zeros(1,4);
LN(1)=(1-a)*Sact_1;
LN(2)=(1-a)*Sact_2;
LN(3)=(1-a)*Sact_3;
LN(4)=(1-a)*Sact_4;

UN=zeros(1,4);
UN(1)=(1+a)*Sact_1;
UN(2)=(1+a)*Sact_2;
UN(3)=(1+a)*Sact_3;
LN(4)=(1-a)*Sact_4;

DeltaL=N-LN;
DeltaU=UN-N;
if min(DeltaL)<0 ||  min(DeltaU)<0
    flag1=0;
else
    flag1=1;
end

if sum(I)*1000<=SWava+GW+OW-QE-QL-QI-b*Sdisturb
    flag2=1;
else
    flag2=0;
end

%适宜性约束
DCS=CSS-CSK;
if min(DCS)>=0
    flag3=1;
else
    flag3=0;
end

flag=flag1*flag2*flag3;
flag=flag1*flag2