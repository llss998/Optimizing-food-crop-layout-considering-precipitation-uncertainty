function f = zhipei_sort_mod(x, M, V)
[N, ~] = size(x);
F1_max=max(x(:,V+1));
F1_min=min(x(:,V+1));
F2_max=max(x(:,V+2));
F2_min=min(x(:,V+2));
F3_max=max(x(:,V+3));
F3_min=min(x(:,V+3));
F4_max=max(x(:,V+4));
F4_min=min(x(:,V+4));

QD=zeros(1,N);
for i=1:N
    QD(i)=(F1_max-x(i,V+1))/(F1_max-F1_min)+(F2_max-x(i,V+2))/(F2_max-F2_min)+(F3_max-x(i,V+3))/(F3_max-F3_min)+(F4_max-x(i,V+4))/(F4_max-F4_min);
end

Front=x;
for i=1:N-1
    A=x(i,:);
    B=x(i+1,:);
    if A(1,V+5)<B(1,V+5)
       Front(i,:)=A; 
       Front(i+1,:)=B;
    elseif A(1,V+5)==B(1,V+5) && QD(i)>=QD(i+1)
       Front(i,:)=A; 
       Front(i+1,:)=B;
    elseif A(1,V+5)==B(1,V+5) && QD(i)<=QD(i+1)
       Front(i,:)=B; 
       Front(i+1,:)=A; 
    end
end
f=Front;
end